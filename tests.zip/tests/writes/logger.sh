#!/bin/bash

date >> test_log.log

node gets.js >> test_log.log 2>> errors.log